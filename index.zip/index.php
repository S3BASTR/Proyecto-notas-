<!DOCTYPE html>
<html>
<head>
<title>Formulario</title>
</head>
<body>

<h1>Inicio de sesion</h1>
 <form>
    Ingrese su nombre: 
    <input  type="text" placeholder="Escribe tu usuario">
    <br>
   Contrasena:
   <input type= "password" placeholder="Escriba contrasena">
   <br>

   <input type="Submit" value="Enviar">


 </form>

</body>
</html>